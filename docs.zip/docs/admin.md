# Admin Module (Users & RBAC)

## What it does
The Admin module handles user management, role management, and granular permissions for the system. It enables assigning roles to users, managing the permissions bound to each role, and enforcing authorization rules via middleware and UI barriers.

## Architecture & Data Flow
The module is designed using Clean Architecture principles, completely decoupling the business logic from the database implementation (Prisma).

**Data Flow Sequence:**
1. **Domain Entity:** Core models encapsulating business invariants (`AdminUser`, `AdminRole`, `AdminPermission`).
2. **Repository Interface:** Defined in the domain layer (`IAdminUserRepository`, `IAdminRoleRepository`).
3. **Repository Implementation:** The Prisma adapters (`PrismaAdminUserRepository`, `PrismaAdminRoleRepository`) map raw database rows into Domain Entities via the Reconstitution pattern (`Entity.reconstitute()`).
4. **Use Case:** Application layer orchestrates business flows. Extracts required data from domain entities and maps to generic DTOs.
5. **Presentation (Server Actions):** Calls Use Cases and handles UI state revalidation (e.g., `createRoleAction`).
6. **UI:** Client-side React components (e.g., `RolesPermissionsView.tsx`, `UsersTableView.tsx`).

## Key Files Touched
- [`src/modules/admin/users/domain/entities/AdminUser.ts`](file:///d:/coalrrnextjs/src/modules/admin/users/domain/entities/AdminUser.ts): Domain entity for Users.
- [`src/modules/admin/roles/domain/entities/AdminRole.ts`](file:///d:/coalrrnextjs/src/modules/admin/roles/domain/entities/AdminRole.ts): Domain entity for Roles.
- [`src/modules/admin/roles/domain/entities/AdminPermission.ts`](file:///d:/coalrrnextjs/src/modules/admin/roles/domain/entities/AdminPermission.ts): Domain entity for Permissions.
- [`src/modules/admin/users/infrastructure/persistence/PrismaAdminUserRepository.ts`](file:///d:/coalrrnextjs/src/modules/admin/users/infrastructure/persistence/PrismaAdminUserRepository.ts): User repository implementation.
- [`src/modules/admin/roles/infrastructure/persistence/PrismaAdminRoleRepository.ts`](file:///d:/coalrrnextjs/src/modules/admin/roles/infrastructure/persistence/PrismaAdminRoleRepository.ts): Role repository implementation.
- `src/modules/admin/users/application/use-cases/*`: All use cases for User lifecycle.
- `src/modules/admin/roles/application/use-cases/*`: All use cases for Roles/Permissions lifecycle.
- `src/modules/admin/roles/presentation/actions.ts`: Presentation layer server actions for roles.
- `src/modules/admin/users/presentation/actions.ts`: Presentation layer server actions for users.
- [`src/infrastructure/di/modules/admin.di.ts`](file:///d:/coalrrnextjs/src/infrastructure/di/modules/admin.di.ts): Dependency Injection container registration for the Admin module.

## Packages Used
- `@prisma/client`: Only inside the infrastructure/persistence layer for executing DB queries.
- `zod`: For input validation inside Server Actions.
